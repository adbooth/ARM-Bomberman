extern int lab7(void);

int main(){
	lab7();
}
